from .module import acinzentar_imagem
from .module import binarizar_imagem